from django.apps import AppConfig


class VideoPublishingConfig(AppConfig):
    name = 'video_publishing'
